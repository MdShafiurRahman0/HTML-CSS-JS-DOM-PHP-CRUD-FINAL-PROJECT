<?php


$contacts = file_exists('contacts.txt') ? file('contacts.txt', FILE_IGNORE_NEW_LINES) : [];


?>


<!DOCTYPE html>


<html>

<head>

  <title>All Contacts</title>

</head>


<body>

<h2>All Contacts</h2>


<?php if (!empty($contacts)): ?>
 
 
    <ul>
    
    
    <?php foreach ($contacts as $contact): ?>
     
     
        <li><?= htmlspecialchars($contact) ?></li>
    
    
        <?php endforeach; ?>
  
  
    </ul>


    <?php else: ?>
  
  
        <p>No contacts found.</p>
    <?php endif; ?>



<a href="add.php">Add New Contact</a>

</body>
</html>
