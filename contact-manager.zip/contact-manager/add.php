<!DOCTYPE html>


<html>


<head>


  <title>Add Contact</title>


</head>

<body>


<h2>Add New Contact</h2>


<form action="save.php" method="POST">


  Name: <input type="text" name="name" required><br><br>


  Email: <input type="text" name="email" required><br><br>


  Phone: <input type="text" name="phone" required><br><br>


  <button type="submit">Save Contact</button>


</form>

<a href="index.php">View All Contacts</a>

</body>

</html>
