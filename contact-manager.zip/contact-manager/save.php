<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $line = $_POST['name'] . ' | ' . $_POST['email'] . ' | ' . $_POST['phone'] . "\n";
    file_put_contents('contacts.txt', $line, FILE_APPEND);
}

header("Location: index.php");
exit;
